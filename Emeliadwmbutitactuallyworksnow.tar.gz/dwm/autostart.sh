#!/bin/sh

picom &

nitrogen --restore &

caffeine &

flameshot &

xfce4-power-manager &

dwm
